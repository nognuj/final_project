const url =
  "https://e87z0kfwe1.execute-api.ap-northeast-2.amazonaws.com/prod/broker";
const axios = require("axios");
const headers = {
  Auth: true,
};
const body = {
  status: 1,
  destination: "pament_attempt",
  payload: {
    fundingId: 1,
    cardNum: "1231535253",
    amount: 100000,
    paymentMethod: "credit card",
    address: "ehddnr4870@gmail.com",
  },
};
(async () => {
  const result = await axios.post(url, body, { headers });
  console.log(result);
})();
